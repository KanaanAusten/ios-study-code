//
//  UrlManager.m
//  多图上传1021
//
//  Created by mac on 15/10/21.
//  Copyright © 2015年 mac. All rights reserved.
//

#import "UrlManager.h"
#import "AFNetworking.h"
@interface UrlManager ()

@property (nonatomic,strong)NSOperationQueue * queue;

@end

@implementation UrlManager

+(instancetype)shareManager
{
    static UrlManager * u = nil;
    static dispatch_once_t oncetoken;
    dispatch_once(&oncetoken, ^{
        u =[[UrlManager alloc]init];
        u.queue =[[NSOperationQueue alloc]init];
    });
    return u;
}

-(void)postStateWithImages:(NSArray *)images andStateBlock:(StateBlock)block{
    
    NSMutableString * urls =[NSMutableString string];
    
    NSMutableArray * operations =[NSMutableArray array];
    
    self.queue.maxConcurrentOperationCount = 1;
    
    for (int i = 0; i < images.count; i++) {
      
        NSData * data = UIImagePNGRepresentation(images[i ]);
        
        NSString * fileName =[NSString stringWithFormat:@"test%d.png",i];
        NSMutableURLRequest * request = [[AFHTTPRequestSerializer serializer]multipartFormRequestWithMethod:@"POST" URLString:@"http://jiaoxue.bjbkws.com/upLoad.php" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            [formData appendPartWithFileData:data name:@"file" fileName:fileName mimeType:@"image/png"];
        } error:nil];
        
        AFHTTPRequestOperation * op =[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        // 文件上传过程中的一个回调
//        [op setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
//            
//        }];
        
        [op setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"s");
            NSDictionary * dic =[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            if ([dic[@"success"] isEqualToString:@"0"]) {
                
                NSString * str =[NSString stringWithFormat:@"%@|",dic[@"url"]];
                [urls appendString:str];
                
           }
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"f");
        }];
        
        //[self.queue addOperation:op];
        
        [operations addObject:op];
        
    }
    
    NSArray * ops =[AFURLConnectionOperation batchOfRequestOperations:operations progressBlock:^(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations) {
        
        NSLog(@"%lu / %lu",numberOfFinishedOperations,totalNumberOfOperations);
        
        
    } completionBlock:^(NSArray *operations) {
        
        
        if (urls.length == 0 ) {
            
            NSLog(@"失败");
            return ;
        }
        NSString * url =[urls substringToIndex:urls.length-1];
        
        NSArray * array = [url componentsSeparatedByString:@"|"];
        
        if (array.count != images.count) {
            
        }
        
        NSLog(@"url = %@",url);
       // 调设置留言接口
       
        [self postLiuYanWithDic:@{@"a":@"ss"} andStateBlock:block];
        
    }];
    
    [self.queue addOperations:ops waitUntilFinished:NO];
    
    
}

-(void)postLiuYanWithDic:(NSDictionary *)dic  andStateBlock:(StateBlock)block
{
    
    NSDictionary * dic1 = @{@"success":@"0"};
    block(dic1);
    
}

@end
