//
//  UrlManager.h
//  多图上传1021
//
//  Created by mac on 15/10/21.
//  Copyright © 2015年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^StateBlock)(NSDictionary *dic);
@interface UrlManager : NSObject

+(instancetype)shareManager;


-(void)postStateWithImages:(NSArray *)images andStateBlock:(StateBlock)block;


@end
