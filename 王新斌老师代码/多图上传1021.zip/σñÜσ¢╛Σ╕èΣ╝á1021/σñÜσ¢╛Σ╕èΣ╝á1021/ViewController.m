//
//  ViewController.m
//  多图上传1021
//
//  Created by mac on 15/10/21.
//  Copyright © 2015年 mac. All rights reserved.
//

#import "ViewController.h"
#import "UrlManager.h"
@interface ViewController ()

@property (nonatomic,strong)NSArray * images;

@property (nonatomic,strong)UrlManager * urlManager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.urlManager =[UrlManager shareManager];
    
    UIImage * image = [UIImage imageNamed:@"1.jpg"];
    UIImage * image1 =[UIImage imageNamed:@"2"];
    UIImage * image2 =[UIImage imageNamed:@"3"];
    
    self.images = @[image,image1,image2];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    [self.urlManager postStateWithImages:self.images andStateBlock:^(NSDictionary *dic) {
        
        NSLog(@"dic = %@",dic);
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
