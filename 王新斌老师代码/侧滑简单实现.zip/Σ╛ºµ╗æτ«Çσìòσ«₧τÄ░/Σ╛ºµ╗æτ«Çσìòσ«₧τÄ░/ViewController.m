//
//  ViewController.m
//  侧滑简单实现
//
//  Created by mac on 15/10/20.
//  Copyright © 2015年 mac. All rights reserved.
//

#import "ViewController.h"
#define OfSetX 100
#define Width self.view.bounds.size.width
@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIView *slideView;

@property (nonatomic,assign)float lastX;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIPanGestureRecognizer * panGestureRecognizer = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(slide:)];
    
    [self.slideView addGestureRecognizer:panGestureRecognizer];
    
}

-(void)slide:(UIPanGestureRecognizer *)sender
{
    CGRect frame = sender.view.frame;
    
    
    if (sender.state == UIGestureRecognizerStateBegan) {
        
        self.lastX = frame.origin.x;
    }
    
    
    CGPoint point =[sender translationInView:sender.view];
    
    NSLog(@"%@",NSStringFromCGPoint(point));
    
    frame.origin.x = point.x + self.lastX;
    
    sender.view.frame = frame;
  
    
    if (sender.state == UIGestureRecognizerStateEnded) {
     
        if (point.x < 100) {
            
            frame.origin.x = 0;
        }
        else
        {
            frame.origin.x = Width - OfSetX;
        }
        
      
        [UIView animateWithDuration:0.5 animations:^{
            
            sender.view.frame = frame;
        }];
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
